import { useRef } from "react";
import { Link } from "react-router-dom";
import { motion, useScroll, useTransform, useMotionValue, useSpring } from "framer-motion";
import { ArrowRight, ArrowUpRight, Play, Sparkles, Clapperboard, TrendingUp } from "lucide-react";
import { MaskedLine, Reveal } from "@/components/Reveal";
import { EditorialMarquee } from "@/components/Marquee";
import { SERVICES, WORKS, HERO_BG, SITE } from "@/lib/site";

const CHAPTERS = [
  {
    num: "01",
    title: "Vision First",
    text: "Every frame starts with your story. Main aapki vision ko samajhta hoon — phir usse screen par zinda karta hoon.",
  },
  {
    num: "02",
    title: "Craft & Chaos",
    text: "Cuts, colour, sound design, motion graphics — har detail pe kaam, taaki final output premium lage.",
  },
  {
    num: "03",
    title: "Made to Impress",
    text: "Reels jo scroll rok de, wedding films jo rula de, promos jo bech de. Create. Edit. Impress.",
  },
];

const Hero = () => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", "25%"]);
  const bgScale = useTransform(scrollYProgress, [0, 1], [1.05, 1.2]);
  const fade = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 60, damping: 20 });
  const sy = useSpring(my, { stiffness: 60, damping: 20 });
  const cardX = useTransform(sx, [-0.5, 0.5], [-18, 18]);
  const cardY = useTransform(sy, [-0.5, 0.5], [-12, 12]);

  const onMouseMove = (e) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    mx.set((e.clientX - r.left) / r.width - 0.5);
    my.set((e.clientY - r.top) / r.height - 0.5);
  };

  return (
    <section
      ref={ref}
      onMouseMove={onMouseMove}
      data-testid="hero-section"
      className="relative min-h-screen flex flex-col justify-end overflow-hidden"
    >
      <motion.div className="absolute inset-0" style={{ y: bgY, scale: bgScale }}>
        <img src={HERO_BG} alt="" aria-hidden="true" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/60" />
      </motion.div>

      <motion.div
        aria-hidden="true"
        style={{ x: cardX, y: cardY }}
        className="absolute right-6 md:right-16 top-32 md:top-40 z-10 hidden sm:flex items-center gap-3 border border-[#E5FF00]/40 bg-black/50 backdrop-blur-xl px-5 py-4 rounded-2xl"
      >
        <span className="w-2.5 h-2.5 rounded-full bg-[#E5FF00] animate-pulse-dot" />
        <p className="text-xs uppercase tracking-[0.2em] text-white/80">Available for projects</p>
      </motion.div>

      <motion.div style={{ opacity: fade }} className="relative z-10 px-4 md:px-8 pb-14 md:pb-20 w-full">
        <MaskedLine delay={0.15}>
          <p className="text-xs md:text-sm uppercase tracking-[0.3em] text-[#E5FF00] mb-6" data-testid="hero-overline">
            Video Creator & Editor — {SITE.area}
          </p>
        </MaskedLine>

        <h1 className="font-display font-black uppercase leading-[0.95] tracking-tighter" data-testid="hero-headline">
          <MaskedLine delay={0.3} className="text-[15vw] md:text-[11vw]">
            <span>Rahul</span>
          </MaskedLine>
          <MaskedLine delay={0.45} className="text-[15vw] md:text-[11vw]">
            <span className="text-stroke-neon">Creates</span>
            <span className="text-[#E5FF00]">X</span>
          </MaskedLine>
        </h1>

        <div className="mt-8 flex flex-col md:flex-row md:items-end md:justify-between gap-8">
          <MaskedLine delay={0.6}>
            <p className="text-base md:text-lg text-[#A3A3A3] max-w-md" data-testid="hero-tagline">
              {SITE.tagline} Cinematic edits, viral reels & brand films — made for you.
            </p>
          </MaskedLine>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.85, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="flex flex-wrap gap-4"
          >
            <Link
              to="/work"
              data-testid="hero-cta-work"
              className="group flex items-center gap-2 bg-[#E5FF00] text-black text-sm font-semibold uppercase tracking-[0.12em] px-7 py-4 rounded-full transition-transform duration-300 hover:scale-105 active:scale-95"
            >
              See My Work
              <ArrowRight size={16} className="transition-transform duration-300 group-hover:translate-x-1" />
            </Link>
            <Link
              to="/contact"
              data-testid="hero-cta-contact"
              className="group flex items-center gap-2 border border-white/25 text-white text-sm font-semibold uppercase tracking-[0.12em] px-7 py-4 rounded-full transition-colors duration-300 hover:border-[#E5FF00] hover:text-[#E5FF00] active:scale-95"
            >
              Let's Talk
              <ArrowUpRight size={16} className="transition-transform duration-300 group-hover:rotate-45" />
            </Link>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
};

const Manifesto = () => (
  <section className="px-4 md:px-8 py-24 md:py-32" data-testid="manifesto-section">
    <Reveal>
      <p className="text-xs uppercase tracking-[0.3em] text-[#E5FF00] mb-4">The Manifesto</p>
      <h2 className="font-display font-bold uppercase text-4xl md:text-5xl lg:text-6xl tracking-tight max-w-3xl">
        Turning Moments Into <span className="text-stroke">Stories</span>
      </h2>
    </Reveal>

    <div className="mt-16 md:mt-24 flex flex-col gap-16 md:gap-20">
      {CHAPTERS.map((c, i) => (
        <Reveal key={c.num} delay={i * 0.08}>
          <div className="grid grid-cols-1 md:grid-cols-[auto_1fr] gap-4 md:gap-16 items-start border-t border-white/10 pt-10" data-testid={`manifesto-chapter-${c.num}`}>
            <span className="font-display font-black text-7xl md:text-8xl text-white/10 leading-none select-none" aria-hidden="true">
              {c.num}
            </span>
            <div>
              <h3 className="font-display font-semibold uppercase text-2xl md:text-3xl tracking-tight">
                {c.title}
              </h3>
              <p className="mt-4 text-base text-[#A3A3A3] max-w-xl leading-relaxed">{c.text}</p>
            </div>
          </div>
        </Reveal>
      ))}
    </div>
  </section>
);

const Services = () => {
  const icons = [Play, Clapperboard, Sparkles, TrendingUp];
  return (
    <section className="px-4 md:px-8 py-24 md:py-32 bg-[#0a0a0a]" data-testid="services-section">
      <Reveal>
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-14">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-[#E5FF00] mb-4">What I Do</p>
            <h2 className="font-display font-bold uppercase text-4xl md:text-5xl lg:text-6xl tracking-tight">
              Services
            </h2>
          </div>
          <p className="text-sm text-[#A3A3A3] max-w-xs">
            9 ways I can level up your content — from reels to full cinematic films.
          </p>
        </div>
      </Reveal>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        {SERVICES.map((s, i) => {
          const Icon = icons[i % icons.length];
          return (
            <Reveal key={s.title} delay={(i % 4) * 0.06} className={s.big ? "md:col-span-2" : ""}>
              <Link
                to="/contact"
                data-testid={`service-card-${i}`}
                className={`group relative flex flex-col justify-between h-full min-h-[190px] bg-[#111111] border border-white/10 p-6 md:p-8 transition-colors duration-500 hover:border-[#E5FF00]/60 ${
                  s.big ? "md:min-h-[220px]" : ""
                }`}
              >
                <div className="flex items-start justify-between">
                  <span className="text-[10px] uppercase tracking-[0.25em] text-[#A3A3A3] group-hover:text-[#E5FF00] transition-colors duration-500">
                    {s.tag}
                  </span>
                  <Icon size={18} className="text-white/30 group-hover:text-[#E5FF00] transition-colors duration-500" />
                </div>
                <div>
                  <h3 className="font-display font-semibold text-lg md:text-xl leading-snug">{s.title}</h3>
                  <p className="mt-2 text-sm text-[#A3A3A3] leading-relaxed">{s.desc}</p>
                </div>
                <ArrowUpRight
                  size={20}
                  className="absolute bottom-6 right-6 text-[#E5FF00] opacity-0 translate-x-2 translate-y-2 group-hover:opacity-100 group-hover:translate-x-0 group-hover:translate-y-0 transition-all duration-500"
                />
              </Link>
            </Reveal>
          );
        })}
      </div>
    </section>
  );
};

const WorkPreview = () => (
  <section className="px-4 md:px-8 py-24 md:py-32" data-testid="work-preview-section">
    <Reveal>
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-14">
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-[#E5FF00] mb-4">Selected Work</p>
          <h2 className="font-display font-bold uppercase text-4xl md:text-5xl lg:text-6xl tracking-tight">
            Recent <span className="text-stroke">Frames</span>
          </h2>
        </div>
        <Link
          to="/work"
          data-testid="work-preview-view-all"
          className="group flex items-center gap-2 text-sm uppercase tracking-[0.15em] text-white/70 hover:text-[#E5FF00] transition-colors duration-300 w-fit"
        >
          View All Work
          <ArrowRight size={16} className="transition-transform duration-300 group-hover:translate-x-1" />
        </Link>
      </div>
    </Reveal>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      {WORKS.slice(0, 4).map((w, i) => (
        <Reveal key={w.title} delay={(i % 2) * 0.1} y={60}>
          <Link to="/work" data-testid={`work-preview-${i}`} className="group block relative overflow-hidden clip-frame aspect-[4/3]">
            <img
              src={w.img}
              alt={w.title}
              loading="lazy"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors duration-500" />
            <div className="absolute bottom-0 left-0 right-0 p-6 flex items-end justify-between">
              <div>
                <p className="text-[10px] uppercase tracking-[0.25em] text-[#E5FF00]">{w.cat}</p>
                <h3 className="font-display font-semibold text-xl mt-1">{w.title}</h3>
              </div>
              <span className="w-11 h-11 rounded-full bg-[#E5FF00] text-black flex items-center justify-center opacity-0 scale-75 group-hover:opacity-100 group-hover:scale-100 transition-all duration-500">
                <Play size={16} fill="currentColor" />
              </span>
            </div>
          </Link>
        </Reveal>
      ))}
    </div>
  </section>
);

const CTABand = () => (
  <section className="px-4 md:px-8 py-24 md:py-32" data-testid="cta-band">
    <Reveal>
      <div className="relative overflow-hidden border border-[#E5FF00]/30 bg-[#111111] px-6 md:px-16 py-16 md:py-24">
        <p className="text-xs uppercase tracking-[0.3em] text-[#E5FF00] mb-6">Got a project in mind?</p>
        <h2 className="font-display font-black uppercase text-4xl md:text-6xl lg:text-7xl tracking-tighter leading-[1.02]">
          Let's Create<br />Something <span className="text-[#E5FF00]">Viral</span>
        </h2>
        <div className="mt-10 flex flex-wrap gap-4">
          <a
            href={SITE.whatsapp}
            target="_blank"
            rel="noopener noreferrer"
            data-testid="cta-whatsapp"
            className="flex items-center gap-2 bg-[#E5FF00] text-black text-sm font-semibold uppercase tracking-[0.12em] px-7 py-4 rounded-full transition-transform duration-300 hover:scale-105 active:scale-95"
          >
            WhatsApp Me <ArrowUpRight size={16} />
          </a>
          <Link
            to="/contact"
            data-testid="cta-contact"
            className="flex items-center gap-2 border border-white/25 text-white text-sm font-semibold uppercase tracking-[0.12em] px-7 py-4 rounded-full transition-colors duration-300 hover:border-[#E5FF00] hover:text-[#E5FF00]"
          >
            Send an Enquiry
          </Link>
        </div>
      </div>
    </Reveal>
  </section>
);

export default function Home() {
  return (
    <main>
      <Hero />
      <EditorialMarquee />
      <Manifesto />
      <Services />
      <WorkPreview />
      <EditorialMarquee />
      <CTABand />
    </main>
  );
}
