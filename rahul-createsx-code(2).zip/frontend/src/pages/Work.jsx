import { Link } from "react-router-dom";
import { Play, ArrowUpRight } from "lucide-react";
import { MaskedLine, Reveal } from "@/components/Reveal";
import { EditorialMarquee } from "@/components/Marquee";
import { WORKS, SERVICES, SITE } from "@/lib/site";

export default function Work() {
  return (
    <main className="pt-32 md:pt-40" data-testid="work-page">
      <section className="px-4 md:px-8">
        <MaskedLine delay={0.1}>
          <p className="text-xs uppercase tracking-[0.3em] text-[#E5FF00] mb-4">Portfolio</p>
        </MaskedLine>
        <h1 className="font-display font-black uppercase tracking-tighter leading-[0.95]" data-testid="work-headline">
          <MaskedLine delay={0.25} className="text-[13vw] md:text-[8vw]">
            <span>The Work</span>
          </MaskedLine>
          <MaskedLine delay={0.4} className="text-[13vw] md:text-[8vw]">
            <span className="text-stroke">Speaks</span>
          </MaskedLine>
        </h1>
        <Reveal delay={0.5}>
          <p className="mt-8 text-base md:text-lg text-[#A3A3A3] max-w-lg">
            Cinematic frames, viral reels and brand stories — har project ek nayi kahani.
          </p>
        </Reveal>
      </section>

      <div className="mt-16 md:mt-24">
        <EditorialMarquee />
      </div>

      <section className="px-4 md:px-8 py-20 md:py-28">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {WORKS.map((w, i) => (
            <Reveal key={w.title} delay={(i % 2) * 0.1} y={60} className={w.span === "tall" ? "md:mt-16" : ""}>
              <div data-testid={`work-item-${i}`} className="group relative overflow-hidden clip-frame aspect-[4/3]">
                <img
                  src={w.img}
                  alt={w.title}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors duration-500" />
                <div className="absolute bottom-0 left-0 right-0 p-6 md:p-8 flex items-end justify-between">
                  <div>
                    <p className="text-[10px] uppercase tracking-[0.25em] text-[#E5FF00]">{w.cat}</p>
                    <h3 className="font-display font-semibold text-xl md:text-2xl mt-1">{w.title}</h3>
                  </div>
                  <span className="w-12 h-12 rounded-full bg-[#E5FF00] text-black flex items-center justify-center opacity-0 scale-75 group-hover:opacity-100 group-hover:scale-100 transition-all duration-500">
                    <Play size={18} fill="currentColor" />
                  </span>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="px-4 md:px-8 py-16 md:py-24 bg-[#0a0a0a]" data-testid="work-services-list">
        <Reveal>
          <h2 className="font-display font-bold uppercase text-3xl md:text-4xl tracking-tight mb-12">
            Everything I <span className="text-[#E5FF00]">Edit</span>
          </h2>
        </Reveal>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
          {SERVICES.map((s, i) => (
            <Reveal key={s.title} delay={(i % 3) * 0.06}>
              <div className="flex items-center justify-between border-b border-white/10 py-4 group" data-testid={`work-service-${i}`}>
                <span className="text-sm md:text-base text-white/80 group-hover:text-[#E5FF00] transition-colors duration-300">
                  {s.title}
                </span>
                <span className="text-xs text-white/30 font-display">{String(i + 1).padStart(2, "0")}</span>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="px-4 md:px-8 py-24 md:py-32">
        <Reveal>
          <div className="flex flex-col items-start gap-8">
            <h2 className="font-display font-black uppercase text-4xl md:text-6xl tracking-tighter">
              Your Project <span className="text-stroke-neon">Next?</span>
            </h2>
            <div className="flex flex-wrap gap-4">
              <a
                href={SITE.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                data-testid="work-whatsapp-cta"
                className="flex items-center gap-2 bg-[#E5FF00] text-black text-sm font-semibold uppercase tracking-[0.12em] px-7 py-4 rounded-full transition-transform duration-300 hover:scale-105 active:scale-95"
              >
                WhatsApp Me <ArrowUpRight size={16} />
              </a>
              <Link
                to="/contact"
                data-testid="work-contact-cta"
                className="flex items-center gap-2 border border-white/25 text-white text-sm font-semibold uppercase tracking-[0.12em] px-7 py-4 rounded-full transition-colors duration-300 hover:border-[#E5FF00] hover:text-[#E5FF00]"
              >
                Contact Page
              </Link>
            </div>
          </div>
        </Reveal>
      </section>
    </main>
  );
}
