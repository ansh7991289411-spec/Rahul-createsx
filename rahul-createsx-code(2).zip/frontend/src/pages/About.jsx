import { MapPin, Clapperboard, Sparkles, Heart } from "lucide-react";
import { MaskedLine, Reveal } from "@/components/Reveal";
import { EditorialMarquee } from "@/components/Marquee";
import { ABOUT_IMG, SITE, SERVICES } from "@/lib/site";

const STATS = [
  { icon: Clapperboard, label: "Services Offered", value: `${SERVICES.length}+` },
  { icon: MapPin, label: "Service Area", value: "Jodhpur & Phalsoond" },
  { icon: Sparkles, label: "Style", value: "Cinematic + Gen-Z" },
  { icon: Heart, label: "Promise", value: "Made for You" },
];

const APPROACH = [
  {
    num: "01",
    title: "Listen",
    text: "Pehle aapki story, audience aur goal samajhta hoon. Har project ka brief hi uski soul hai.",
  },
  {
    num: "02",
    title: "Create",
    text: "Footage, colour grading, sound design, motion graphics — sab kuch ek premium cinematic flow me.",
  },
  {
    num: "03",
    title: "Deliver",
    text: "On-time delivery, platform-ready formats, aur revisions jab tak aap impress na ho.",
  },
];

export default function About() {
  return (
    <main className="pt-32 md:pt-40" data-testid="about-page">
      <section className="px-4 md:px-8">
        <MaskedLine delay={0.1}>
          <p className="text-xs uppercase tracking-[0.3em] text-[#E5FF00] mb-4">About Me</p>
        </MaskedLine>
        <h1 className="font-display font-black uppercase tracking-tighter leading-[0.95]" data-testid="about-headline">
          <MaskedLine delay={0.25} className="text-[12vw] md:text-[7vw]">
            <span>The Guy Behind</span>
          </MaskedLine>
          <MaskedLine delay={0.4} className="text-[12vw] md:text-[7vw]">
            <span className="text-stroke">The Cut</span>
          </MaskedLine>
        </h1>
      </section>

      <section className="px-4 md:px-8 mt-16 md:mt-24 grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
        <Reveal y={60}>
          <div className="relative overflow-hidden clip-frame aspect-[4/5]" data-testid="about-portrait">
            <img src={ABOUT_IMG} alt="Rahul CreatesX editing studio" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/20" />
            <div className="absolute bottom-6 left-6 border border-[#E5FF00]/40 bg-black/60 backdrop-blur-xl px-4 py-3 rounded-xl">
              <p className="text-xs uppercase tracking-[0.2em] text-white/80">Rahul CreatesX</p>
              <p className="text-[10px] text-[#A3A3A3] mt-1">{SITE.instagramHandle}</p>
            </div>
          </div>
        </Reveal>

        <div className="flex flex-col gap-10">
          <Reveal delay={0.1}>
            <p className="text-base md:text-lg text-[#A3A3A3] leading-relaxed" data-testid="about-bio">
              Rahul CreatesX is a creative video editing and video production service based in Rajasthan.
              I create engaging, cinematic and professional videos designed for social media, personal
              brands, businesses and special events. Clean edits, bold storytelling, aur wo Gen-Z energy
              jo content ko viral banati hai.
            </p>
          </Reveal>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {STATS.map((s, i) => (
              <Reveal key={s.label} delay={0.15 + i * 0.06}>
                <div className="bg-[#111111] border border-white/10 p-6 hover:border-[#E5FF00]/50 transition-colors duration-500" data-testid={`about-stat-${i}`}>
                  <s.icon size={20} className="text-[#E5FF00]" />
                  <p className="font-display font-semibold text-lg mt-4">{s.value}</p>
                  <p className="text-xs uppercase tracking-[0.2em] text-[#A3A3A3] mt-1">{s.label}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <div className="mt-24">
        <EditorialMarquee />
      </div>

      <section className="px-4 md:px-8 py-24 md:py-32" data-testid="about-approach">
        <Reveal>
          <p className="text-xs uppercase tracking-[0.3em] text-[#E5FF00] mb-4">The Process</p>
          <h2 className="font-display font-bold uppercase text-4xl md:text-5xl tracking-tight mb-16">
            How I <span className="text-stroke">Work</span>
          </h2>
        </Reveal>
        <div className="flex flex-col gap-14">
          {APPROACH.map((a, i) => (
            <Reveal key={a.num} delay={i * 0.08}>
              <div className="grid grid-cols-1 md:grid-cols-[auto_1fr] gap-4 md:gap-16 items-start border-t border-white/10 pt-10" data-testid={`approach-chapter-${a.num}`}>
                <span className="font-display font-black text-7xl md:text-8xl text-white/10 leading-none select-none" aria-hidden="true">
                  {a.num}
                </span>
                <div>
                  <h3 className="font-display font-semibold uppercase text-2xl md:text-3xl tracking-tight">{a.title}</h3>
                  <p className="mt-4 text-base text-[#A3A3A3] max-w-xl leading-relaxed">{a.text}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </main>
  );
}
