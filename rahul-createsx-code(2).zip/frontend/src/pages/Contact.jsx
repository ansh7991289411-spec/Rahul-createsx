import { useState } from "react";
import axios from "axios";
import { toast } from "sonner";
import { FaInstagram, FaWhatsapp } from "react-icons/fa";
import { Phone, Send, Loader2 } from "lucide-react";
import { MaskedLine, Reveal } from "@/components/Reveal";
import { SITE, SERVICES } from "@/lib/site";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

export default function Contact() {
  const [form, setForm] = useState({ name: "", phone: "", service: SERVICES[0].title, message: "" });
  const [loading, setLoading] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim() || !form.message.trim()) {
      toast.error("Please fill name, phone and message.");
      return;
    }
    setLoading(true);
    try {
      await axios.post(`${API}/enquiries`, form);
      toast.success("Enquiry sent! Rahul will get back to you soon.");
      setForm({ name: "", phone: "", service: SERVICES[0].title, message: "" });
    } catch {
      toast.error("Something went wrong. Try WhatsApp instead.");
    } finally {
      setLoading(false);
    }
  };

  const inputCls =
    "w-full bg-[#111111] border border-white/15 px-5 py-4 text-sm text-white placeholder:text-white/30 outline-none transition-colors duration-300 focus:border-[#E5FF00] rounded-none";

  return (
    <main className="pt-32 md:pt-40" data-testid="contact-page">
      <section className="px-4 md:px-8">
        <MaskedLine delay={0.1}>
          <p className="text-xs uppercase tracking-[0.3em] text-[#E5FF00] mb-4">Contact</p>
        </MaskedLine>
        <h1 className="font-display font-black uppercase tracking-tighter leading-[0.95]" data-testid="contact-headline">
          <MaskedLine delay={0.25} className="text-[13vw] md:text-[8vw]">
            <span>Let's</span>
          </MaskedLine>
          <MaskedLine delay={0.4} className="text-[13vw] md:text-[8vw]">
            <span className="text-[#E5FF00]">Create</span>
          </MaskedLine>
        </h1>
        <Reveal delay={0.5}>
          <p className="mt-8 text-base md:text-lg text-[#A3A3A3] max-w-lg">
            Available for: Jodhpur • Phalsoond • Online Projects. Drop a message — reply fast, promise.
          </p>
        </Reveal>

        <Reveal delay={0.6}>
          <div className="mt-10 flex flex-wrap gap-4">
            <a
              href={SITE.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              data-testid="contact-whatsapp-button"
              className="flex items-center gap-2.5 bg-[#E5FF00] text-black text-sm font-semibold uppercase tracking-[0.12em] px-7 py-4 rounded-full transition-transform duration-300 hover:scale-105 active:scale-95"
            >
              <FaWhatsapp size={18} /> WhatsApp — {SITE.phoneDisplay}
            </a>
            <a
              href={SITE.phone}
              data-testid="contact-call-button"
              className="flex items-center gap-2.5 border border-white/25 text-white text-sm font-semibold uppercase tracking-[0.12em] px-7 py-4 rounded-full transition-colors duration-300 hover:border-[#E5FF00] hover:text-[#E5FF00] active:scale-95"
            >
              <Phone size={16} /> Call Now
            </a>
            <a
              href={SITE.instagram}
              target="_blank"
              rel="noopener noreferrer"
              data-testid="contact-instagram-button"
              className="flex items-center gap-2.5 border border-white/25 text-white text-sm font-semibold uppercase tracking-[0.12em] px-7 py-4 rounded-full transition-colors duration-300 hover:border-[#E5FF00] hover:text-[#E5FF00] active:scale-95"
            >
              <FaInstagram size={16} /> {SITE.instagramHandle}
            </a>
          </div>
        </Reveal>
      </section>

      <section className="px-4 md:px-8 py-24 md:py-32 grid grid-cols-1 lg:grid-cols-[1fr_auto] gap-16">
        <Reveal>
          <form onSubmit={submit} className="flex flex-col gap-5 max-w-2xl" data-testid="contact-form">
            <p className="text-xs uppercase tracking-[0.3em] text-[#E5FF00]">Send an Enquiry</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <input
                data-testid="contact-form-name"
                className={inputCls}
                placeholder="Your name"
                value={form.name}
                onChange={set("name")}
              />
              <input
                data-testid="contact-form-phone"
                className={inputCls}
                placeholder="Phone / WhatsApp number"
                value={form.phone}
                onChange={set("phone")}
              />
            </div>
            <select
              data-testid="contact-form-service"
              className={`${inputCls} appearance-none cursor-pointer`}
              value={form.service}
              onChange={set("service")}
            >
              {SERVICES.map((s) => (
                <option key={s.title} value={s.title} className="bg-[#111111]">
                  {s.title}
                </option>
              ))}
            </select>
            <textarea
              data-testid="contact-form-message"
              className={`${inputCls} min-h-[150px] resize-y`}
              placeholder="Tell me about your project — event date, video type, vibe..."
              value={form.message}
              onChange={set("message")}
            />
            <button
              type="submit"
              disabled={loading}
              data-testid="contact-form-submit"
              className="group flex items-center justify-center gap-2 bg-[#E5FF00] text-black text-sm font-semibold uppercase tracking-[0.12em] px-7 py-4 rounded-full transition-transform duration-300 hover:scale-[1.03] active:scale-95 disabled:opacity-60 disabled:hover:scale-100 w-fit"
            >
              {loading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} className="transition-transform duration-300 group-hover:translate-x-1" />}
              {loading ? "Sending..." : "Send Enquiry"}
            </button>
          </form>
        </Reveal>

        <Reveal delay={0.15}>
          <div className="bg-[#111111] border border-white/10 p-8 lg:w-80 flex flex-col gap-6" data-testid="contact-info-card">
            <div>
              <p className="text-xs uppercase tracking-[0.2em] text-[#A3A3A3]">Based in</p>
              <p className="font-display font-semibold text-lg mt-2">Jodhpur & Phalsoond, Rajasthan</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-[0.2em] text-[#A3A3A3]">Phone</p>
              <a href={SITE.phone} className="font-display font-semibold text-lg mt-2 block hover:text-[#E5FF00] transition-colors duration-300">
                {SITE.phoneDisplay}
              </a>
            </div>
            <div>
              <p className="text-xs uppercase tracking-[0.2em] text-[#A3A3A3]">Instagram</p>
              <a href={SITE.instagram} target="_blank" rel="noopener noreferrer" className="font-display font-semibold text-lg mt-2 block hover:text-[#E5FF00] transition-colors duration-300">
                {SITE.instagramHandle}
              </a>
            </div>
            <div className="border-t border-white/10 pt-6">
              <p className="text-sm text-[#A3A3A3] leading-relaxed">
                Professional Visuals, Made for You.
              </p>
            </div>
          </div>
        </Reveal>
      </section>
    </main>
  );
}
