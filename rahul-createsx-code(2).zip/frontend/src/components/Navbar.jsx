import { useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, ArrowUpRight } from "lucide-react";
import { SITE } from "@/lib/site";

const LINKS = [
  { to: "/", label: "Home" },
  { to: "/work", label: "Work" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

export const Navbar = () => {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      <nav className="mx-4 md:mx-8 mt-4 flex items-center justify-between border border-white/10 bg-black/60 backdrop-blur-xl px-5 md:px-8 py-4">
        <Link to="/" data-testid="nav-logo" className="font-display text-sm md:text-base font-bold tracking-tight uppercase">
          Rahul<span className="text-[#E5FF00]">CreatesX</span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          {LINKS.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              data-testid={`nav-link-${l.label.toLowerCase()}`}
              className={({ isActive }) =>
                `relative text-xs uppercase tracking-[0.2em] transition-colors duration-300 ${
                  isActive ? "text-[#E5FF00]" : "text-white/60 hover:text-white"
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
          <a
            href={SITE.whatsapp}
            target="_blank"
            rel="noopener noreferrer"
            data-testid="nav-hire-button"
            className="group flex items-center gap-1.5 bg-[#E5FF00] text-black text-xs font-semibold uppercase tracking-[0.15em] px-5 py-2.5 rounded-full transition-transform duration-300 hover:scale-105 active:scale-95"
          >
            Hire Me
            <ArrowUpRight size={14} className="transition-transform duration-300 group-hover:rotate-45" />
          </a>
        </div>

        <button
          data-testid="nav-menu-toggle"
          onClick={() => setOpen(!open)}
          className="md:hidden text-white p-1"
          aria-label="Toggle menu"
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            data-testid="nav-mobile-menu"
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
            className="md:hidden mx-4 mt-2 border border-white/10 bg-black/90 backdrop-blur-xl p-6 flex flex-col gap-5"
          >
            {LINKS.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                data-testid={`nav-mobile-link-${l.label.toLowerCase()}`}
                className={({ isActive }) =>
                  `font-display text-lg uppercase ${isActive ? "text-[#E5FF00]" : "text-white/70"}`
                }
              >
                {l.label}
              </NavLink>
            ))}
            <a
              href={SITE.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              data-testid="nav-mobile-hire-button"
              className="mt-2 flex items-center justify-center gap-2 bg-[#E5FF00] text-black text-sm font-semibold uppercase tracking-[0.15em] px-5 py-3 rounded-full"
            >
              Hire Me <ArrowUpRight size={16} />
            </a>
          </motion.div>
        )}
      </AnimatePresence>
      <span className="sr-only">{location.pathname}</span>
    </header>
  );
};
