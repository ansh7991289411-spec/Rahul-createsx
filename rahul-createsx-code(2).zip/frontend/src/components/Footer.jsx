import { Link } from "react-router-dom";
import { FaInstagram, FaWhatsapp } from "react-icons/fa";
import { Phone } from "lucide-react";
import { SITE } from "@/lib/site";

export const Footer = () => (
  <footer className="border-t border-white/10 mt-24" data-testid="site-footer">
    <div className="px-4 md:px-8 py-16 grid grid-cols-1 md:grid-cols-3 gap-12">
      <div>
        <p className="font-display text-xl uppercase font-bold">
          Rahul<span className="text-[#E5FF00]">CreatesX</span>
        </p>
        <p className="mt-4 text-sm text-[#A3A3A3] max-w-xs leading-relaxed">
          Video creator & editor turning moments into cinematic stories. Based in Rajasthan, working worldwide.
        </p>
      </div>
      <div className="flex flex-col gap-3">
        <p className="text-xs uppercase tracking-[0.2em] text-[#A3A3A3]">Explore</p>
        {[
          { to: "/", label: "Home" },
          { to: "/work", label: "Work" },
          { to: "/about", label: "About" },
          { to: "/contact", label: "Contact" },
        ].map((l) => (
          <Link
            key={l.to}
            to={l.to}
            data-testid={`footer-link-${l.label.toLowerCase()}`}
            className="text-sm text-white/70 hover:text-[#E5FF00] transition-colors duration-300 w-fit"
          >
            {l.label}
          </Link>
        ))}
      </div>
      <div className="flex flex-col gap-3">
        <p className="text-xs uppercase tracking-[0.2em] text-[#A3A3A3]">Connect</p>
        <a href={SITE.instagram} target="_blank" rel="noopener noreferrer" data-testid="footer-instagram" className="flex items-center gap-2 text-sm text-white/70 hover:text-[#E5FF00] transition-colors duration-300 w-fit">
          <FaInstagram size={15} /> {SITE.instagramHandle}
        </a>
        <a href={SITE.whatsapp} target="_blank" rel="noopener noreferrer" data-testid="footer-whatsapp" className="flex items-center gap-2 text-sm text-white/70 hover:text-[#E5FF00] transition-colors duration-300 w-fit">
          <FaWhatsapp size={15} /> {SITE.phoneDisplay}
        </a>
        <a href={SITE.phone} data-testid="footer-call" className="flex items-center gap-2 text-sm text-white/70 hover:text-[#E5FF00] transition-colors duration-300 w-fit">
          <Phone size={15} /> Call Directly
        </a>
        <p className="text-xs text-[#A3A3A3] mt-2">{SITE.area}</p>
      </div>
    </div>
    <div className="overflow-hidden px-4 md:px-8 pb-6" aria-hidden="true">
      <p className="font-display font-black uppercase text-[13vw] leading-none text-stroke whitespace-nowrap select-none">
        CREATESX
      </p>
    </div>
    <div className="border-t border-white/10 px-4 md:px-8 py-5 flex flex-col md:flex-row justify-between gap-2 text-xs text-[#A3A3A3]">
      <p>© {new Date().getFullYear()} Rahul CreatesX. All rights reserved.</p>
      <p>Create. Edit. Impress.</p>
    </div>
  </footer>
);
