import Marquee from "react-fast-marquee";

const WORDS = ["Cinematic", "Bold", "Trendy", "Engaging", "Reels", "Stories", "Edits", "Visuals"];

export const EditorialMarquee = ({ className = "" }) => (
  <div className={`border-y border-white/10 py-6 md:py-8 overflow-hidden ${className}`} aria-hidden="true">
    <Marquee speed={35} gradient={false}>
      {WORDS.map((w, i) => (
        <span key={w} className="flex items-center">
          <span
            className={`font-display font-extrabold uppercase text-4xl md:text-6xl px-6 ${
              i % 2 === 0 ? "text-white" : "text-stroke"
            }`}
          >
            {w}
          </span>
          <span className="w-3 h-3 rounded-full bg-[#E5FF00] mx-2 inline-block" />
        </span>
      ))}
    </Marquee>
  </div>
);
